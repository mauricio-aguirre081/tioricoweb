# Formulario WEB que envía los datos al Whatsapp de tu negocio

Formulario de reservas para Barbería o para cualquier negocio que use Whatsapp para comunicarse con sus clientes.

Permite que el cliente haga el primer contacto con el whatsapp del negocio.

Si en tu Whatsapp te llegan mensajes como "hola", "están atendiendo?"... o similares

En cambio deseas recibir un mensaje con la informacion del cliente, su nombre, detalles del pedido entre otros...

Con este formulario web puedes solicitar a tus clientes la informacion que necesites.

Luego de darle click al boton de enviar te llegará al whatsapp de tu negocio toda la info que le solicitaste.

Puedes modificar los campos a tu gusto y necesidades.

Si quieres probar como funciona llena el formulario aquí: [https://elisperez.github.io/FormWebToWhatsapp/](https://elisperez.github.io/FormWebToWhatsapp/)

Yo estaré del otro lado respondiendo tus dudas por mi Whatsapp :-)
